columbia-  →  https://t.me/s/columbiamo/<num> 
e-  →  https://t.me/s/extratone/<num> 
i-  →  https://github.com/extratone/i/issues/<num> 
keys-  →  https://github.com/extratone/keys/issues/<num> 
odette-  →  https://github.com/extratone/odette/issues/<num> 
t-  →  https://github.com/extratone/t/issues/<num>

